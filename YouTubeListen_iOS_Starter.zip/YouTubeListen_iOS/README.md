# YouTube Listen — iOS starter

A personal-use SwiftUI iPhone app. Paste a YouTube video URL, play it in YouTube's official embedded player, and save favorites locally.

## Playback limitations
- No audio extraction, MP3 conversion, downloading, or separation of audio tracks.
- The official YouTube player, controls, and branding remain visible.
- No background or screen-off playback. YouTube's developer policies prohibit API clients from enabling background play. YouTube Premium offers background playback in the official YouTube and YouTube Music apps.
- Some videos cannot be embedded due to creator settings, age restrictions, or YouTube limitations.

## Open in Xcode
1. On a Mac, install Xcode.
2. Create a new iOS App project named `YouTubeListen` (SwiftUI, Swift).
3. Add the four Swift files in the `YouTubeListen` folder to the project (select “Copy items if needed”).
4. Set the deployment target to iOS 16 or later.
5. Set a unique Bundle Identifier, choose your Apple development team, and run on your iPhone.

The WebView currently uses `https://example.com` as a placeholder base URL. Before distributing the app, replace it with a domain you control and follow YouTube's current client-identity and Referer requirements.

No server or account is required. This is source code; it is not a signed, installable iPhone app.
