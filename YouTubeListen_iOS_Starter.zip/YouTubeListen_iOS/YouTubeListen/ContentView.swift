import SwiftUI

struct ContentView: View {
    @AppStorage("savedYouTubeFavorites") private var favoritesData = Data()
    @State private var urlText = ""
    @State private var currentLink: YouTubeLink?
    @State private var favorites: [YouTubeLink] = []
    @State private var errorMessage: String?

    private let accent = Color(red: 1, green: 0.12, blue: 0.16)

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.055, green: 0.06, blue: 0.075).ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        header
                        inputSection

                        if let currentLink {
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    sectionLabel("NOW PLAYING")
                                    Spacer()
                                    Button {
                                        toggleFavorite(currentLink)
                                    } label: {
                                        Image(systemName: isFavorite(currentLink) ? "heart.fill" : "heart")
                                            .foregroundStyle(isFavorite(currentLink) ? accent : .white)
                                            .font(.title3)
                                    }
                                }
                                YouTubePlayerView(videoID: currentLink.videoID)
                                    .frame(height: 240)
                                    .clipShape(RoundedRectangle(cornerRadius: 16))
                                Text(currentLink.title).font(.subheadline.weight(.semibold))
                                Text("Playback is provided by YouTube. Keep the player visible while listening.")
                                    .font(.footnote).foregroundStyle(.secondary)
                            }
                        } else {
                            VStack(spacing: 12) {
                                Image(systemName: "waveform")
                                    .font(.system(size: 36, weight: .light)).foregroundStyle(accent)
                                Text("Your player is ready").font(.headline)
                                Text("Paste a YouTube video link above to start.")
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity).padding(.vertical, 38)
                            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18))
                        }

                        favoritesSection
                    }
                    .padding(20)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .onAppear(perform: loadFavorites)
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "play.rectangle.fill")
                .font(.title2).foregroundStyle(.white)
                .frame(width: 46, height: 46)
                .background(accent, in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 2) {
                Text("YouTube Listen").font(.title2.bold())
                Text("Your personal listening space").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(.top, 12)
    }

    private var inputSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionLabel("PLAY A VIDEO")
            HStack(spacing: 10) {
                Image(systemName: "link").foregroundStyle(.secondary)
                TextField("Paste a YouTube link", text: $urlText)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                    .autocorrectionDisabled()
                    .submitLabel(.go)
                    .onSubmit(loadVideo)
            }
            .padding(15)
            .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))

            Button(action: loadVideo) {
                Label("Load video", systemImage: "play.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 15)
                    .background(accent, in: RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)

            if let errorMessage {
                Text(errorMessage).font(.footnote).foregroundStyle(.orange)
            }
        }
    }

    private var favoritesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                sectionLabel("FAVORITES")
                Spacer()
                Text("\\(favorites.count)").font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }
            if favorites.isEmpty {
                Text("Videos you save will appear here.")
                    .font(.subheadline).foregroundStyle(.secondary).padding(.vertical, 8)
            } else {
                ForEach(favorites) { item in
                    HStack(spacing: 12) {
                        Image(systemName: "play.rectangle").font(.title2).foregroundStyle(accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.title).font(.subheadline.weight(.medium))
                            Text(item.videoID).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button {
                            currentLink = item
                            urlText = item.originalURL
                            errorMessage = nil
                        } label: {
                            Image(systemName: "play.circle.fill").font(.title2)
                        }
                        .buttonStyle(.plain)
                        Button {
                            toggleFavorite(item)
                        } label: {
                            Image(systemName: "heart.fill").foregroundStyle(accent)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(12)
                    .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }

    private func sectionLabel(_ title: String) -> some View {
        Text(title).font(.caption.weight(.bold)).tracking(1.4).foregroundStyle(.secondary)
    }

    private func loadVideo() {
        guard let link = YouTubeLink.parse(urlText) else {
            errorMessage = "Enter a valid YouTube video link (youtube.com or youtu.be)."
            return
        }
        currentLink = link
        errorMessage = nil
    }

    private func loadFavorites() {
        guard let decoded = try? JSONDecoder().decode([YouTubeLink].self, from: favoritesData) else { return }
        favorites = decoded
    }

    private func saveFavorites() {
        favoritesData = (try? JSONEncoder().encode(favorites)) ?? Data()
    }

    private func isFavorite(_ link: YouTubeLink) -> Bool {
        favorites.contains(where: { $0.videoID == link.videoID })
    }

    private func toggleFavorite(_ link: YouTubeLink) {
        if isFavorite(link) {
            favorites.removeAll(where: { $0.videoID == link.videoID })
        } else {
            favorites.insert(link, at: 0)
        }
        saveFavorites()
    }
}
