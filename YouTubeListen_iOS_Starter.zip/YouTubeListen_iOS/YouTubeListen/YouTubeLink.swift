import Foundation

struct YouTubeLink: Identifiable, Codable, Equatable {
    var id: String { videoID }
    let videoID: String
    let originalURL: String
    var title: String { "YouTube video • \\(videoID)" }

    static func parse(_ raw: String) -> YouTubeLink? {
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URLComponents(string: cleaned),
              let host = url.host?.lowercased() else { return nil }

        var candidate: String?
        if host == "youtu.be" || host == "www.youtu.be" {
            candidate = url.path.split(separator: "/").first.map(String.init)
        } else if ["youtube.com", "www.youtube.com", "m.youtube.com"].contains(host) {
            if url.path == "/watch" {
                candidate = url.queryItems?.first(where: { $0.name == "v" })?.value
            } else if url.path.hasPrefix("/shorts/") || url.path.hasPrefix("/embed/") {
                candidate = url.path.split(separator: "/").last.map(String.init)
            }
        }

        guard let videoID = candidate,
              videoID.range(of: #"^[A-Za-z0-9_-]{11}$"#, options: .regularExpression) != nil
        else { return nil }

        return YouTubeLink(videoID: videoID, originalURL: cleaned)
    }
}
